/*
  PitchToNote

  This file is a modified copy of the:
  https://github.com/arduino/tutorials/blob/master/ArduinoZeroMidi/PitchToNote.h
*/

#define NOTE_C8 108

#define NOTE_B7 107
#define NOTE_B7b 106
#define NOTE_A7 105
#define NOTE_A7b 104
#define NOTE_G7 103
#define NOTE_G7b 102
#define NOTE_F7 101
#define NOTE_E7 100
#define NOTE_E7b 99
#define NOTE_D7 98
#define NOTE_D7b 97
#define NOTE_C7 96

#define NOTE_B6 95
#define NOTE_B6b 94
#define NOTE_A6 93
#define NOTE_A6b 92
#define NOTE_G6 91
#define NOTE_G6b 90
#define NOTE_F6 89
#define NOTE_E6 88
#define NOTE_E6b 87
#define NOTE_D6 86
#define NOTE_D6b 85
#define NOTE_C6 84

#define NOTE_B5 83
#define NOTE_B5b 82
#define NOTE_A5 81
#define NOTE_A5b 80
#define NOTE_G5 79
#define NOTE_G5b 78
#define NOTE_F5 77
#define NOTE_E5 76
#define NOTE_E5b 75
#define NOTE_D5 74
#define NOTE_D5b 73
#define NOTE_C5 72

#define NOTE_B4 71
#define NOTE_B4b 70
#define NOTE_A4 69
#define NOTE_A4b 68
#define NOTE_G4 67
#define NOTE_G4b 66
#define NOTE_F4 65
#define NOTE_E4 64
#define NOTE_E4b 63
#define NOTE_D4 62
#define NOTE_D4b 61
#define NOTE_C4 60

#define NOTE_B3 59
#define NOTE_B3b 58
#define NOTE_A3 57
#define NOTE_A3b 56
#define NOTE_G3 55
#define NOTE_G3b 54
#define NOTE_F3 53
#define NOTE_E3 52
#define NOTE_E3b 51
#define NOTE_D3 50
#define NOTE_D3b 49
#define NOTE_C3 48

#define NOTE_B2 47
#define NOTE_B2b 46
#define NOTE_A2 45
#define NOTE_A2b 44
#define NOTE_G2 43
#define NOTE_G2b 42
#define NOTE_F2 41
#define NOTE_E2 40
#define NOTE_E2b 39
#define NOTE_D2 38
#define NOTE_D2b 37
#define NOTE_C2 36

#define NOTE_B1 35
#define NOTE_B1b 34
#define NOTE_A1 33
#define NOTE_A1b 32
#define NOTE_G1 31
#define NOTE_G1b 30
#define NOTE_F1 29
#define NOTE_E1 28
#define NOTE_E1b 27
#define NOTE_D1 26
#define NOTE_D1b 25
#define NOTE_C1 24

#define NOTE_B0 23
#define NOTE_B0b 22
#define NOTE_A0 21
